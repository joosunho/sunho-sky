(async function () {
  const elList = document.getElementById('list');
  const elYear = document.getElementById('year');
  const elQ = document.getElementById('q');
  elYear.textContent = new Date().getFullYear();

  const res = await fetch('./data/notices.json', { cache: 'no-store' });
  const all = await res.json();

  const render = (items) => {
    elList.innerHTML = '';
    if (!items.length) {
      elList.innerHTML = '<p class="empty">검색 결과가 없습니다.</p>';
      return;
    }
    for (const it of items) {
      const card = document.createElement('article');
      card.className = 'card';
      card.innerHTML = `
        <h2>${escapeHTML(it.title)}</h2>
        <div class="meta">${dateStr(it.date)} · ${it.author ? escapeHTML(it.author) : '운영자'}</div>
        ${it.tags?.length ? it.tags.map(t => `<span class="tag">${escapeHTML(t)}</span>`).join('') : ''}
        <div>${mdToHTML(it.body)}</div>
      `;
      elList.appendChild(card);
    }
  };

  const byDateDesc = [...all].sort((a,b)=> new Date(b.date) - new Date(a.date));
  render(byDateDesc);

  elQ?.addEventListener('input', (e)=>{
    const q = e.target.value.trim().toLowerCase();
    if (!q) return render(byDateDesc);
    const filtered = byDateDesc.filter(it =>
      (it.title || '').toLowerCase().includes(q) ||
      (it.body || '').toLowerCase().includes(q)  ||
      (it.tags || []).some(t => (t||'').toLowerCase().includes(q))
    );
    render(filtered);
  });

  function dateStr(s){
    const d = new Date(s);
    if (isNaN(d)) return s;
    return d.toLocaleDateString('ko-KR', { year:'numeric', month:'2-digit', day:'2-digit' });
  }
  function escapeHTML(s=''){
    return s.replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  }
  function mdToHTML(s=''){
    return escapeHTML(s)
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\[(.+?)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>')
      .replace(/\n/g, '<br>');
  }
})();